import { Dataset, createPuppeteerRouter } from 'crawlee';

export const router = createPuppeteerRouter();

router.addDefaultHandler(async ({ request, page, log }) => {
    await page.setRequestInterception(true);
    page.on('request', (req) => {
        req.abort();
    });

    const title = await page.title();
    if (title === 'Sign Up | LinkedIn' || title === 'www.linkedin.com') {
        return;
    }

    log.info(`${title}`, { url: request.loadedUrl });

    const content = await page.content();
    await Dataset.pushData({
        url: request.url,
        loadedUrl: request.loadedUrl,
        title,
        content,
        retryCount: request.retryCount
    });
});
